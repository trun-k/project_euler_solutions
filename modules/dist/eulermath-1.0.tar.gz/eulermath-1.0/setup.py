from setuptools import setup

setup(
    name='eulermath',
    version = '1.0',
    description='List of varous functions that I will use whie solving Project Euler questions',
    author = 'trun_k',
    author_email='tarunk0205@gmail.com',
    py_module = ['eulermath']
)